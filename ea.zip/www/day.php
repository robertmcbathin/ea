<?
include_once 'inc/header.php';
if(!$loggedin) exit;
?>
<div class="container">

</div>
<?
include_once 'inc/footer.php';
?>