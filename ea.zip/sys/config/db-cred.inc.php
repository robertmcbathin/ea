<?
 $C = array();
 $C['DB_HOST'] = 'localhost';
 $C['DB_USER'] = 'root';
 $C['DB_PASS'] = '';
 $C['DB_NAME'] = 'endoadmin';
?>